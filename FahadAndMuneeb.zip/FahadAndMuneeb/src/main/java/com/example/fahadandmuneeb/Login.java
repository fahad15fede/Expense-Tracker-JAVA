package com.example.fahadandmuneeb;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class Login {
    public Login(){};


    @FXML
    public TextField login_pass;

    @FXML
    public TextField login_username;

    public  String getLogin_pass(){
        return login_pass.getText();
    }

    public  String getLogin_username() {
        return login_username.getText();
    }


    @FXML
    void Switch_to_register(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("Sign-up.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    void log_in(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Details.fxml")));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

}
