package com.example.fahadandmuneeb;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;
import java.util.Scanner;
import java.io.BufferedWriter;

public class SignUp {


    @FXML
    private Button SignUp;

    @FXML
    private  TextField pass;

    @FXML
    private TextField repass;

    @FXML
    private  TextField username;



    @FXML
    void register(ActionEvent event) {

        try{

            if(pass.getText().equals(repass.getText()) && username.getText().length()>=5){
                BufferedWriter File1 = new BufferedWriter(new FileWriter("C:\\Users\\Fahad\\FahadAndMuneeb\\registeredPeople\\"+username.getText()+" "+pass.getText()));
                File1.write(username.getText()+" \n"+pass.getText()+" \n"+repass.getText());
                File1.close();
                showAlert("Great Success","Your ID has been created.");
            }
            else if (!(pass.getText().equals(repass.getText()))){
                showAlert("Error", "Both passwords must match.");
            } else if (username.getText().length()<5) {
               showAlert("Error","Username must have at least 5 characters.");
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }
    @FXML
    void Log_inPage(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Login.fxml")));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }


}