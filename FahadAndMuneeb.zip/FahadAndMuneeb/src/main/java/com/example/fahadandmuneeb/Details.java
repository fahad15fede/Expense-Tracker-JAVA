package com.example.fahadandmuneeb;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Details  {

    public Details(Login user1){

    }

    @FXML
    private TextField AssetsInput;

    @FXML
    private TextField BillInput;

    @FXML
    private TextField MonthlyExpenseInput;

    @FXML
    private TextField ProfitLossInput;

    @FXML
    private TextField currencyInput;

    @FXML
    void SaveChanges(ActionEvent event) throws IOException {

        Login loggedUser = new Login();
        Details user1 = new Details(loggedUser);

       BufferedWriter file1 =  new BufferedWriter(new FileWriter("C:\\Users\\Fahad\\FahadAndMuneeb\\registeredPeople\\"+loggedUser.getLogin_username()+" "+loggedUser.getLogin_pass()));
       file1.write("Currency : "+currencyInput.getText()+"\n"+"Assets : "+AssetsInput.getText()+"\n"+"Bills : "+BillInput.getText()+"\n"+"Monthly Expense : "+MonthlyExpenseInput.getText()+"\n"+"Profit or Loss : "+ProfitLossInput.getText());
       file1.close();
    }

}
//if(pass.getText().equals(repass.getText()) && username.getText().length()>=5){
//        BufferedWriter File1 = new BufferedWriter(new FileWriter("C:\\Users\\Fahad\\FahadAndMuneeb\\registeredPeople\\"+username.getText()+" "+pass.getText()));
//        File1.write(username.getText()+" \n"+pass.getText()+" \n"+repass.getText());
//        File1.close();
//        showAlert("Great Success","Your ID has been created.");
//        }